let questions = [
  {
    question: "राजस्थान की राजधानी क्या है?",
    options: ["जोधपुर", "कोटा", "जयपुर", "बीकानेर"],
    answer: "जयपुर"
  },
  {
    question: "थार मरुस्थल कहाँ है?",
    options: ["गुजरात", "मध्य प्रदेश", "राजस्थान", "उत्तर प्रदेश"],
    answer: "राजस्थान"
  },
  {
    question: "चित्तौड़गढ़ किला किससे जुड़ा है?",
    options: ["रानी पद्मिनी", "मीरा बाई", "महाराणा प्रताप", "राणा सांगा"],
    answer: "रानी पद्मिनी"
  },
  {
    question: "जयसमंद झील कहाँ है?",
    options: ["बाड़मेर", "अलवर", "उदयपुर", "जैसलमेर"],
    answer: "उदयपुर"
  },
  {
    question: "राजस्थान में सबसे बड़ा जिला कौन सा है?",
    options: ["बाड़मेर", "नागौर", "बीकानेर", "जोधपुर"],
    answer: "जैसलमेर"
  }
];

let current = 0;
let score = 0;
let startTime;
let timerInterval;

function startQuiz() {
  const name = document.getElementById("username").value.trim();
  if (!name) {
    alert("कृपया नाम दर्ज करें");
    return;
  }

  document.querySelector("#quiz").style.display = "block";
  document.querySelector("#submitBtn").style.display = "block";
  startTime = new Date();
  timerInterval = setInterval(updateTimer, 1000);
  loadQuestion();
}

function updateTimer() {
  let now = new Date();
  let diff = Math.floor((now - startTime) / 1000);
  let minutes = String(Math.floor(diff / 60)).padStart(2, '0');
  let seconds = String(diff % 60).padStart(2, '0');
  document.getElementById("timer").textContent = `⏱️ समय: ${minutes}:${seconds}`;
}

function loadQuestion() {
  let q = questions[current];
  document.getElementById("questionBox").textContent = q.question;
  let optionsHTML = "";
  q.options.forEach(opt => {
    optionsHTML += `<button onclick="selectAnswer(this, '${opt}')">${opt}</button><br>`;
  });
  document.getElementById("optionsBox").innerHTML = optionsHTML;
}

function selectAnswer(button, selected) {
  let correct = questions[current].answer;
  let allButtons = document.querySelectorAll("#optionsBox button");
  allButtons.forEach(btn => btn.disabled = true);

  if (selected === correct) {
    button.classList.add("correct");
    score++;
  } else {
    button.classList.add("wrong");
  }

  setTimeout(() => {
    current++;
    if (current < questions.length) {
      loadQuestion();
    } else {
      submitQuiz();
    }
  }, 1000);
}

function submitQuiz() {
  clearInterval(timerInterval);
  document.getElementById("quiz").style.display = "none";
  document.getElementById("submitBtn").style.display = "none";
  document.getElementById("result").innerHTML =
    `<h3>आपका स्कोर: ${score}/${questions.length}</h3>`;
}
